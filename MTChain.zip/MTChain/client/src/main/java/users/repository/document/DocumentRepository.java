package users.repository.document;

import org.springframework.data.jpa.datatables.repository.DataTablesRepository;
import org.springframework.stereotype.Repository;
import users.repository.document.model.Document;

@Repository("documentRepository")
public interface DocumentRepository extends DataTablesRepository<Document, Long> {

    public Document findByid(Long id);
}
