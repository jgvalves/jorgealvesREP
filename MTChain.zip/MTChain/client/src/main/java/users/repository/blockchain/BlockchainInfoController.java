package users.repository.blockchain;

public class BlockchainInfoController {
}
