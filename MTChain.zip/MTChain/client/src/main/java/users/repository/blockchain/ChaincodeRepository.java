package users.repository.blockchain;

import org.springframework.data.jpa.datatables.repository.DataTablesRepository;
import org.springframework.stereotype.Repository;
//import users.repository.blockchain.Model.Chaincodes;

@Repository("chaincodeRepository")
public interface ChaincodeRepository{//} extends DataTablesRepository<Chaincodes, Long> {

}
