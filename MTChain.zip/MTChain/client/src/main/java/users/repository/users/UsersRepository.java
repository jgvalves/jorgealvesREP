package users.repository.users;

import org.springframework.data.jpa.datatables.repository.DataTablesRepository;
import org.springframework.stereotype.Repository;
import users.repository.users.Model.Users;

@Repository("usersRepository")
public interface UsersRepository extends DataTablesRepository<Users, Long> {
    Users findByuserid(Long id);
}