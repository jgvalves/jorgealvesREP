package users.repository.document;

public class DocumentController {
}
