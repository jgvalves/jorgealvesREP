package users.repository.document;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import users.repository.document.model.Document;
import users.repository.document.model.Signers;
import users.repository.users.Model.Users;

import javax.transaction.Transactional;

@Service("documentService")
public class DocumentService {

    @Autowired
    private DocumentRepository documentRepository;

    @Transactional
    public Document addNewDocument(String name, String description, Users emitter, String hash, Signers signers){
        Document d = new Document(name, description, emitter, hash, signers);
        documentRepository.save(d);
        return d;
    }

    @Transactional
    public void saveDocChanges(Document document){
        documentRepository.save(document);
    }

}
